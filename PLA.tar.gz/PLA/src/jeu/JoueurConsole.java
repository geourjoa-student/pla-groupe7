package jeu;

import java.util.Scanner;

public abstract class JoueurConsole extends Joueur{
	
	

}
