package jeu;

public class JoueurConsoleFleches extends JoueurConsole {

	public JoueurConsoleFleches(String nom) {
		this.nom=nom;
	}

	@Override
	public Action getNouvelleAction() {
		// TODO Comment lire une fleche au clavier ? 
		return null;
	}

}
