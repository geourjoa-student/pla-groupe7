package jeu;

public class Heros extends Personnage{

	public Heros(Joueur joueur, Case caseSousLeJoueur) {
		this.caseSousLeJoueur=caseSousLeJoueur;
		proprietaire=joueur;
		pointsDeVie = 100;
		comportement=null;//TODO automate
	}

}
