package jeu;

public enum Type {
	
	ARBRE,
	CHAMPS,
	HERBE;

}
