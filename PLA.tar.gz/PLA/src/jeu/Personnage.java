package jeu;

import automate.Automate;

public abstract class Personnage {
	
	protected Case caseSousLeJoueur;
	
	protected int pointsDeVie;
	
	protected Joueur proprietaire;
	
	protected Automate comportement;

	public Joueur getJoueur() { //DOUBLON
		return proprietaire;
	}

	public Joueur getProprietaire() { //DOUBLON
		return proprietaire;
	}


	public void allerADroite() { //Tests � faire
		caseSousLeJoueur= caseSousLeJoueur.getCaseDroite();
		
	}
	
	public void allerAGauche() {
		caseSousLeJoueur= caseSousLeJoueur.getCaseGauche();
		
	}
	
	public void allerEnBas() {
		caseSousLeJoueur= caseSousLeJoueur.getCaseBas();
		
	}
	
	public void allerEnHaut() {
		caseSousLeJoueur= caseSousLeJoueur.getCaseHaut();
		
	}

	

}
